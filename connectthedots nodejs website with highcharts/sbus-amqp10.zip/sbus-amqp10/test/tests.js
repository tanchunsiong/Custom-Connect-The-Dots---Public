var should      = require('should');

describe('SbusAdapter', function() {
    describe('#send()', function () {
        it('should send to amqp client', function () {
            // @todo: Tests are needed.
        });
    });
});